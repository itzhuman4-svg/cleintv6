package dev.nebula;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Adds the contents of a shulker box to its tooltip. Registered through a proxy so it works whichever
 * way Fabric's ItemTooltipCallback is declared in this version.
 */
final class ShulkerPreview {
	static void register() {
		for (String cn : new String[]{"net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback", "net.fabricmc.fabric.api.item.v1.ItemTooltipCallback"}) {
			try {
				Class<?> cb = Class.forName(cn);
				Object event = cb.getField("EVENT").get(null);
				Object proxy = Proxy.newProxyInstance(cb.getClassLoader(), new Class<?>[]{cb}, (p, m, a) -> {
					if (m.getDeclaringClass() == Object.class) {
						return switch (m.getName()) { case "hashCode" -> System.identityHashCode(p); case "equals" -> p == a[0]; default -> "NebulaShulkerPreview"; };
					}
					try { handle(a); } catch (Throwable t) { NebulaClient.LOG.debug("shulker preview failed", t); }
					return null;
				});
				for (Method m : event.getClass().getMethods()) {
					if (m.getName().equals("register") && m.getParameterCount() == 1) { m.invoke(event, proxy); return; }
				}
			} catch (Throwable ignored) { }
		}
		NebulaClient.LOG.warn("Shulker preview could not hook item tooltips");
	}

	@SuppressWarnings("unchecked")
	private static void handle(Object[] a) {
		Modules.Mod m = Modules.m("shulkerpreview");
		if (m == null || !m.on() || a == null) return;
		ItemStack stack = null;
		List<Component> lines = null;
		for (Object o : a) {
			if (o instanceof ItemStack s) stack = s;
			else if (o instanceof List<?> l) lines = (List<Component>) l;
		}
		if (stack == null || lines == null || !stack.getItem().getDescriptionId().contains("shulker_box")) return;

		Object contents = stack.get(DataComponents.CONTAINER);
		if (contents == null) return;
		Object items = Compat.invoke(contents, "nonEmptyItems");
		if (items == Compat.FAIL) items = Compat.invoke(contents, "stream");
		List<ItemStack> all = new ArrayList<>();
		if (items instanceof Iterable<?> it) { for (Object o : it) if (o instanceof ItemStack s) all.add(s); }
		else if (items instanceof Stream<?> st) { for (Object o : st.toList()) if (o instanceof ItemStack s) all.add(s); }
		if (all.isEmpty()) return;

		Map<String, Integer> counts = new LinkedHashMap<>();
		for (ItemStack s : all) if (!s.isEmpty()) counts.merge(s.getHoverName().getString(), s.getCount(), Integer::sum);

		int max = (int) m.num("max"), shown = 0;
		lines.add(Component.literal("Contents:").withStyle(Style.EMPTY.withColor(0x7FD6FF)));
		for (Map.Entry<String, Integer> e : counts.entrySet()) {
			if (shown >= max) { lines.add(Component.literal("  ...and " + (counts.size() - shown) + " more").withStyle(Style.EMPTY.withColor(0x8A94A6))); break; }
			lines.add(Component.literal("  " + e.getValue() + "x " + e.getKey()).withStyle(Style.EMPTY.withColor(0xDDDDDD)));
			shown++;
		}
	}

	private ShulkerPreview() {}
}
