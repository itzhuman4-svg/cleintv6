package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

/** Projects world positions onto the GUI using the real camera (works in first and third person). */
final class Proj {
	static double cx, cy, cz;
	static double rx, ry, rz, ux, uy, uz, fx, fy, fz;
	static double tanHalf, aspect;
	static int sw, sh;

	static void update(Minecraft mc) {
		sw = mc.getWindow().getGuiScaledWidth();
		sh = mc.getWindow().getGuiScaledHeight();

		Object cam = Compat.invoke(mc.gameRenderer, "mainCamera");
		if (cam == Compat.FAIL) cam = Compat.invoke(mc.gameRenderer, "getMainCamera");

		Vec3 pos = null;
		float yaw = mc.player.getYRot(), pitch = mc.player.getXRot();
		if (cam != Compat.FAIL && cam != null) {
			Object p = Compat.invoke(cam, "position");
			if (p == Compat.FAIL) p = Compat.invoke(cam, "getPosition");
			if (p instanceof Vec3 v) pos = v;
			Object y = Compat.invoke(cam, "yRot");
			if (y == Compat.FAIL) y = Compat.invoke(cam, "getYRot");
			if (y instanceof Float f) yaw = f;
			Object x = Compat.invoke(cam, "xRot");
			if (x == Compat.FAIL) x = Compat.invoke(cam, "getXRot");
			if (x instanceof Float f) pitch = f;
		}
		if (pos == null) pos = mc.player.getEyePosition();
		cx = pos.x; cy = pos.y; cz = pos.z;

		double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
		fx = -Math.sin(yr) * Math.cos(pr); fy = -Math.sin(pr); fz = Math.cos(yr) * Math.cos(pr);
		rx = -Math.cos(yr); ry = 0; rz = -Math.sin(yr);
		ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx;

		tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2);
		aspect = (double) sw / Math.max(1, sh);
	}

	/** Camera space: {right, up, forward}. */
	static double[] cam(double x, double y, double z) {
		double dx = x - cx, dy = y - cy, dz = z - cz;
		return new double[]{dx * rx + dy * ry + dz * rz, dx * ux + dy * uy + dz * uz, dx * fx + dy * fy + dz * fz};
	}

	static double[] screen(double[] c) {
		double nx = (c[0] / c[2]) / (tanHalf * aspect), ny = (c[1] / c[2]) / tanHalf;
		return new double[]{sw / 2.0 * (1 + nx), sh / 2.0 * (1 - ny)};
	}

	/** Screen position or null when behind the camera. */
	static double[] point(double x, double y, double z) {
		double[] c = cam(x, y, z);
		return c[2] < 0.05 ? null : screen(c);
	}

	/** Draws a clipped 3D line. Alpha fades from a0 to a1 (0-255) along the line. */
	static void line(GuiGraphicsExtractor g, double[] a, double[] b, int rgb, int a0, int a1, int thick) {
		if (a[2] < 0.05 && b[2] < 0.05) return;
		double[] p = a, q = b;
		if (p[2] < 0.05) { double t = (0.05 - p[2]) / (q[2] - p[2]); p = new double[]{p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, 0.05}; }
		if (q[2] < 0.05) { double t = (0.05 - q[2]) / (p[2] - q[2]); q = new double[]{q[0] + (p[0] - q[0]) * t, q[1] + (p[1] - q[1]) * t, 0.05}; }
		double[] s = screen(p), e = screen(q);
		double x0 = s[0], y0 = s[1], x1 = e[0], y1 = e[1];

		// Liang-Barsky clip to the screen
		double dx = x1 - x0, dy = y1 - y0, t0 = 0, t1 = 1;
		double[] pp = {-dx, dx, -dy, dy}, qq = {x0, sw - x0, y0, sh - y0};
		for (int i = 0; i < 4; i++) {
			if (pp[i] == 0) { if (qq[i] < 0) return; }
			else {
				double r = qq[i] / pp[i];
				if (pp[i] < 0) { if (r > t1) return; if (r > t0) t0 = r; }
				else { if (r < t0) return; if (r < t1) t1 = r; }
			}
		}
		double sx = x0 + dx * t0, sy = y0 + dy * t0, ex = x0 + dx * t1, ey = y0 + dy * t1;
		int steps = (int) Math.max(Math.abs(ex - sx), Math.abs(ey - sy));
		if (steps <= 0) steps = 1;
		int h = thick / 2;
		for (int i = 0; i <= steps; i++) {
			double t = i / (double) steps, tt = t0 + (t1 - t0) * t;
			int al = (int) (a0 + (a1 - a0) * tt);
			int x = (int) Math.round(sx + (ex - sx) * t), y = (int) Math.round(sy + (ey - sy) * t);
			g.fill(x - h, y - h, x - h + thick, y - h + thick, (Math.max(0, Math.min(255, al)) << 24) | (rgb & 0xFFFFFF));
		}
	}

	private Proj() {}
}
