package dev.nebula;

/** State for freelook: the camera turns with the mouse while the player keeps their rotation. */
public final class Freelook {
	public static boolean active;
	public static boolean cameraHookSeen, turnHookSeen;
	public static float yaw, pitch;
	public static boolean front;

	public static boolean hooksReady() { return cameraHookSeen && turnHookSeen; }

	public static void turn(double dYaw, double dPitch) {
		yaw += (float) dYaw * 0.15f;
		pitch = Math.max(-90f, Math.min(90f, pitch + (float) dPitch * 0.15f));
	}

	public static float camYaw() { return front ? yaw + 180f : yaw; }
	public static float camPitch() { return front ? -pitch : pitch; }

	private Freelook() {}
}
