package dev.nebula;

import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Pixel-art previews for cosmetics, stored as colour runs in assets/nebula/previews.txt. */
final class Previews {
	private static Map<String, List<int[]>> cache;

	private static void load() {
		cache = new HashMap<>();
		try (BufferedReader r = new BufferedReader(new InputStreamReader(
				Previews.class.getResourceAsStream("/assets/nebula/previews.txt"), StandardCharsets.UTF_8))) {
			String line;
			while ((line = r.readLine()) != null) {
				int tab = line.indexOf('\t');
				if (tab < 0) continue;
				List<int[]> runs = new ArrayList<>();
				for (String s : line.substring(tab + 1).split(";")) {
					if (s.isEmpty()) continue;
					String[] p = s.split(",");
					runs.add(new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]),
							Integer.parseInt(p[3]), 0xFF000000 | Integer.parseInt(p[4], 16)});
				}
				cache.put(line.substring(0, tab), runs);
			}
		} catch (Throwable t) {
			NebulaClient.LOG.warn("Could not load cosmetic previews", t);
		}
	}

	static void draw(GuiGraphicsExtractor g, int cat, String id, int x, int y) {
		if (cache == null) load();
		g.fill(x, y, x + 40, y + 40, 0xFF161B26);
		List<int[]> runs = cache.get(cat + "/" + id);
		if (runs == null) return;
		for (int[] q : runs) g.fill(x + q[0], y + q[1], x + q[0] + q[2], y + q[1] + q[3], q[4]);
	}

	/** Draws a named image without a background tile (e.g. the logo). */
	static void drawRaw(GuiGraphicsExtractor g, String key, int x, int y) {
		if (cache == null) load();
		List<int[]> runs = cache.get(key);
		if (runs == null) return;
		for (int[] q : runs) g.fill(x + q[0], y + q[1], x + q[0] + q[2], y + q[1] + q[3], q[4]);
	}

	private Previews() {}
}
