package dev.nebula;

import net.minecraft.client.Minecraft;

import java.util.HashMap;
import java.util.Map;

/** Zoom, fullbright, FOV, sprint, freelook and FPS Boost. */
final class Features {
	private static boolean zooming;
	private static double zoomP, savedSens;
	private static int savedFov;
	private static long lastNs;

	private static boolean fullbrightOn;
	private static double savedGamma;

	private static boolean fovOn;
	private static int fovSaved;

	private static boolean sprintForced, persp;
	private static Object prevCam;

	private static final Map<String, Object> fpsOrig = new HashMap<>();
	private static final Map<String, String> fpsOpt = new HashMap<>();
	private static int fpsTimer;

	/** Runs every rendered frame: smooth zoom. */
	static void frame(Minecraft mc) {
		long ns = System.nanoTime();
		double dt = lastNs == 0 ? 0.016 : Math.min(0.1, (ns - lastNs) / 1e9);
		lastNs = ns;

		Modules.Mod z = Modules.m("zoom");
		if (!z.on() || mc.player == null) { if (zooming) endZoom(mc); zoomP = 0; return; }

		boolean want = NebulaClient.zoomKey.isDown() && mc.gui.screen() == null;
		double target = want ? 1 : 0;
		if (!z.flag("smooth")) {
			zoomP = target;
		} else {
			zoomP += (target - zoomP) * (1 - Math.exp(-z.num("speed") * dt));
			if (Math.abs(target - zoomP) < 0.004) zoomP = target;
		}

		if (zoomP > 0 && !zooming) {
			savedFov = mc.options.fov().get();
			savedSens = mc.options.sensitivity().get();
			zooming = true;
		}
		if (zooming) {
			Opt.force(mc.options.fov(), (int) Math.round(savedFov + (z.num("fov") - savedFov) * zoomP));
			Opt.force(mc.options.sensitivity(), savedSens * (1 - 0.65 * zoomP));
			if (zoomP <= 0 && !want) endZoom(mc);
		}
	}

	private static void endZoom(Minecraft mc) {
		Opt.force(mc.options.fov(), savedFov);
		Opt.force(mc.options.sensitivity(), savedSens);
		zooming = false;
	}

	static void tick(Minecraft mc) {
		fpsBoost(mc);
		if (mc.player == null || mc.level == null) return;
		if (Modules.on("hurtcam")) mc.player.hurtTime = 0;
		fullbright(mc);
		fovChanger(mc);
		sprint(mc);
		freelook(mc);
	}

	private static void fullbright(Minecraft mc) {
		Modules.Mod m = Modules.m("fullbright");
		if (m.on()) {
			if (!fullbrightOn) { savedGamma = mc.options.gamma().get(); fullbrightOn = true; }
			Opt.force(mc.options.gamma(), m.num("level"));
		} else if (fullbrightOn) {
			Opt.force(mc.options.gamma(), savedGamma);
			fullbrightOn = false;
		}
	}

	private static void fovChanger(Minecraft mc) {
		Modules.Mod m = Modules.m("fov");
		if (m.on() && !zooming) {
			if (!fovOn) { fovSaved = mc.options.fov().get(); fovOn = true; }
			int v = (int) m.num("fov");
			if (mc.options.fov().get() != v) Opt.force(mc.options.fov(), v);
		} else if (!m.on() && fovOn && !zooming) {
			Opt.force(mc.options.fov(), fovSaved);
			fovOn = false;
		}
	}

	private static void sprint(Minecraft mc) {
		Modules.Mod m = Modules.m("sprint");
		var o = mc.options;
		boolean any = m.opt("mode") == 1;
		boolean moving = o.keyUp.isDown() || (any && (o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown()));
		boolean tooHungry = mc.player.getFoodData().getFoodLevel() <= 6 && !mc.player.getAbilities().mayfly;
		boolean go = m.on() && mc.gui.screen() == null && moving && !mc.player.isShiftKeyDown()
				&& !mc.player.isUsingItem() && !tooHungry;
		if (go) {
			o.keySprint.setDown(true);
			sprintForced = true;
		} else if (sprintForced) {
			o.keySprint.setDown(false);
			sprintForced = false;
		}
	}

	/** Hold the key to look around freely. Falls back to a plain third-person view if the camera hooks are missing. */
	private static void freelook(Minecraft mc) {
		Modules.Mod m = Modules.m("perspective");
		boolean want = m.on() && NebulaClient.perspKey.isDown() && mc.gui.screen() == null;
		if (want) {
			if (!persp) {
				persp = true;
				prevCam = Compat.invoke(mc.options, "getCameraType");
				Freelook.front = m.opt("view") == 1;
				Freelook.yaw = mc.player.getYRot();
				Freelook.pitch = mc.player.getXRot();
				Freelook.active = Freelook.hooksReady();
			}
			Object cam = Compat.enumConst("net.minecraft.client.CameraType", Freelook.front ? "THIRD_PERSON_FRONT" : "THIRD_PERSON_BACK");
			if (cam != null) Compat.invoke(mc.options, "setCameraType", cam);
		} else if (persp) {
			Freelook.active = false;
			if (prevCam != null && prevCam != Compat.FAIL) Compat.invoke(mc.options, "setCameraType", prevCam);
			persp = false;
		}
	}

	// ------------------------------------------------------------ FPS Boost

	private static void fpsBoost(Minecraft mc) {
		if (++fpsTimer % 40 != 0 || mc.options == null) return;
		Modules.Mod m = Modules.m("fpsboost");
		boolean on = m.on();
		int particles = m.opt("particles");
		boost(mc, "particles", "particles", on && particles > 0 ? (particles == 2 ? "MINIMAL" : "DECREASED") : null, false);
		boost(mc, "clouds", "cloudStatus", on && m.flag("clouds") ? "OFF" : null, false);
		boost(mc, "shadows", "entityShadows", on && m.flag("shadows") ? Boolean.FALSE : null, false);
		boost(mc, "blend", "biomeBlendRadius", on && m.flag("blend") ? Integer.valueOf(1) : null, false);
		boost(mc, "framerate", "framerateLimit", on && m.flag("framerate") ? Integer.valueOf(260) : null, false);
		boost(mc, "vsync", "enableVsync", on && m.flag("vsync") ? Boolean.FALSE : null, false);
		int rd = (int) m.num("renderdist");
		boost(mc, "renderdist", "renderDistance", on && rd > 0 ? Integer.valueOf(rd) : null, true);
	}

	private static void boost(Minecraft mc, String key, String optName, Object wanted, boolean cap) {
		Object opt = Compat.invoke(mc.options, optName);
		if (opt == Compat.FAIL || opt == null) return;
		Object cur = Compat.invoke(opt, "get");
		if (cur == Compat.FAIL || cur == null) return;

		if (wanted != null) {
			Object w = convert(wanted, cur);
			if (w == null) return;
			if (cap && w instanceof Integer wi && cur instanceof Integer ci && wi >= ci && !fpsOrig.containsKey(key)) return;
			if (!fpsOrig.containsKey(key)) { fpsOrig.put(key, cur); fpsOpt.put(key, optName); }
			if (!w.equals(cur)) Compat.invoke(opt, "set", w);
		} else if (fpsOrig.containsKey(key)) {
			Object orig = fpsOrig.remove(key);
			fpsOpt.remove(key);
			if (!orig.equals(cur)) Compat.invoke(opt, "set", orig);
		}
	}

	/** Drops FPS Boost's saved originals (used when a performance profile takes over). */
	static void forgetBoost() { fpsOrig.clear(); fpsOpt.clear(); }

	static Object convert(Object wanted, Object cur) {
		if (cur instanceof Enum<?> e && wanted instanceof String s) {
			for (Object c : e.getDeclaringClass().getEnumConstants()) if (((Enum<?>) c).name().equals(s)) return c;
			return null;
		}
		if (cur instanceof Boolean && wanted instanceof Boolean) return wanted;
		if (cur instanceof Integer && wanted instanceof Number n) return n.intValue();
		if (cur instanceof Double && wanted instanceof Number n) return n.doubleValue();
		return null;
	}

	/** Called when the game closes so options.txt never saves our temporary overrides. */
	static void restoreAll(Minecraft mc) {
		if (zooming) endZoom(mc);
		if (fullbrightOn) { Opt.force(mc.options.gamma(), savedGamma); fullbrightOn = false; }
		if (fovOn) { Opt.force(mc.options.fov(), fovSaved); fovOn = false; }
		for (Map.Entry<String, Object> e : new HashMap<>(fpsOrig).entrySet()) {
			Object opt = Compat.invoke(mc.options, fpsOpt.get(e.getKey()));
			if (opt != Compat.FAIL && opt != null) Compat.invoke(opt, "set", e.getValue());
		}
		fpsOrig.clear();
	}

	private Features() {}
}
