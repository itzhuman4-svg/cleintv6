package dev.nebula;

import net.minecraft.client.Minecraft;

import java.lang.management.ManagementFactory;

/** Performance profiles (Potato/Low/Medium/High) and live usage numbers. */
final class Perf {
	static final String[] NAMES = {"POTATO", "LOW", "MEDIUM", "HIGH"};
	static final String[] DESC = {
			"Render distance 4, minimal particles, no clouds, no shadows, no biome blend. Cosmetic particles off. Best FPS.",
			"Render distance 8, fewer particles, no clouds, no entity shadows, light biome blend.",
			"Render distance 12, fewer particles, fast clouds, shadows on. Balanced.",
			"Render distance 16, all particles, fancy clouds, full biome blend. Best looks."};

	private static final int[] RD = {4, 8, 12, 16}, SD = {5, 6, 8, 10}, BLEND = {0, 1, 3, 5}, MIP = {0, 1, 2, 4};
	private static final String[] PART = {"MINIMAL", "DECREASED", "DECREASED", "ALL"}, CLOUD = {"OFF", "OFF", "FAST", "FANCY"};
	private static final double[] ENT = {0.5, 0.75, 1.0, 1.25};

	static final int[] hist = new int[120];
	static int histPos, histCount;
	static double cpuProc = -1, cpuSys = -1;
	private static int cpuTimer;

	static void tick(Minecraft mc) {
		hist[histPos] = mc.getFps();
		histPos = (histPos + 1) % hist.length;
		histCount = Math.min(hist.length, histCount + 1);
		if (++cpuTimer >= 10) {
			cpuTimer = 0;
			cpuProc = cpu("getProcessCpuLoad");
			cpuSys = cpu("getCpuLoad", "getSystemCpuLoad");
		}
	}

	static int sample(int i) { return hist[Math.floorMod(histPos - histCount + i, hist.length)]; }

	static double avgFps() {
		if (histCount == 0) return 0;
		long sum = 0;
		for (int i = 0; i < histCount; i++) sum += sample(i);
		return sum / (double) histCount;
	}

	/** Average of the slowest 1% of samples. */
	static double lowFps() {
		if (histCount == 0) return 0;
		int[] c = new int[histCount];
		for (int i = 0; i < histCount; i++) c[i] = sample(i);
		java.util.Arrays.sort(c);
		int n = Math.max(1, histCount / 20);
		long sum = 0;
		for (int i = 0; i < n; i++) sum += c[i];
		return sum / (double) n;
	}

	static int maxFps() { int m = 1; for (int i = 0; i < histCount; i++) m = Math.max(m, sample(i)); return m; }

	static long usedMb() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / 1048576; }
	static long allocMb() { return Runtime.getRuntime().totalMemory() / 1048576; }
	static long maxMb() { return Runtime.getRuntime().maxMemory() / 1048576; }

	private static Object os(String... names) {
		try {
			Object os = ManagementFactory.getOperatingSystemMXBean();
			Class<?> c = Class.forName("com.sun.management.OperatingSystemMXBean");
			if (!c.isInstance(os)) return null;
			for (String n : names) {
				try { return c.getMethod(n).invoke(os); } catch (NoSuchMethodException ignored) { }
			}
		} catch (Throwable ignored) { }
		return null;
	}

	private static double cpu(String... names) {
		Object v = os(names);
		return v instanceof Double d && d >= 0 ? d : -1;
	}

	static long sysTotalMb() { Object v = os("getTotalMemorySize", "getTotalPhysicalMemorySize"); return v instanceof Long l ? l / 1048576 : -1; }
	static long sysFreeMb() { Object v = os("getFreeMemorySize", "getFreePhysicalMemorySize"); return v instanceof Long l ? l / 1048576 : -1; }

	/** Applies a profile to the video options. Names that don't exist in this version are skipped. */
	static void apply(Minecraft mc, int level) {
		Features.forgetBoost();
		set(mc, "renderDistance", RD[level]);
		set(mc, "simulationDistance", SD[level]);
		set(mc, "particles", PART[level]);
		set(mc, "cloudStatus", CLOUD[level]);
		set(mc, "entityShadows", level >= 2);
		set(mc, "biomeBlendRadius", BLEND[level]);
		set(mc, "entityDistanceScaling", ENT[level]);
		set(mc, "mipmapLevels", MIP[level]);
		if (level <= 1) { set(mc, "enableVsync", false); set(mc, "framerateLimit", 260); }
		Config.I.perfProfile = level;
		Config.save();
	}

	private static void set(Minecraft mc, String name, Object wanted) {
		Object opt = Compat.invoke(mc.options, name);
		if (opt == Compat.FAIL || opt == null) return;
		Object cur = Compat.invoke(opt, "get");
		if (cur == Compat.FAIL || cur == null) return;
		Object w = Features.convert(wanted, cur);
		if (w != null && !w.equals(cur)) Compat.invoke(opt, "set", w);
	}

	private Perf() {}
}
