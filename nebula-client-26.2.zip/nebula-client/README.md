# Nebula Client (Fabric, Minecraft 26.2)

Client-side mod by Orbitive. Needs JDK 25+, Fabric Loader 0.19.3+, Fabric API 0.156.0+26.2.

Build: `gradle build`. Jar: build/libs/nebula-client-1.0.0.jar (not -sources).

Keys: Right Shift = menu, C (hold) = zoom, Left Alt (hold) = freelook, B = add waypoint.
Menu tabs: MODS, PERFORMANCE (profiles + live usage), SETTINGS, WAYPOINTS. Profiles in the sidebar.
