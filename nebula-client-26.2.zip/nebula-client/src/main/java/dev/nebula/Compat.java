package dev.nebula;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/** Reflection helpers for Minecraft calls whose names change between versions. They fail softly. */
final class Compat {
	static final Object FAIL = new Object();

	static Object get(Object o, String name) {
		if (o == null) return null;
		for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
			try {
				Field f = c.getDeclaredField(name);
				f.setAccessible(true);
				return f.get(o);
			} catch (NoSuchFieldException ignored) {
			} catch (Throwable t) {
				return null;
			}
		}
		return null;
	}

	static Object staticField(Class<?> c, String name) {
		try {
			Field f = c.getDeclaredField(name);
			if (!Modifier.isStatic(f.getModifiers())) return null;
			f.setAccessible(true);
			return f.get(null);
		} catch (Throwable t) {
			return null;
		}
	}

	static Object enumConst(String cls, String name) {
		try {
			for (Object e : Class.forName(cls).getEnumConstants())
				if (((Enum<?>) e).name().equals(name)) return e;
		} catch (Throwable ignored) { }
		return null;
	}

	/** Calls a method by name; returns FAIL if no matching method exists or all attempts throw. */
	static Object invoke(Object o, String name, Object... args) {
		if (o == null) return FAIL;
		for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
			for (Method m : c.getDeclaredMethods()) {
				if (!m.getName().equals(name) || m.getParameterCount() != args.length || !fits(m.getParameterTypes(), args)) continue;
				try {
					m.setAccessible(true);
					return m.invoke(o, args);
				} catch (Throwable ignored) { }
			}
		}
		return FAIL;
	}

	private static boolean fits(Class<?>[] types, Object[] args) {
		for (int i = 0; i < types.length; i++) {
			Class<?> t = wrap(types[i]);
			if (args[i] == null ? types[i].isPrimitive() : !t.isInstance(args[i])) return false;
		}
		return true;
	}

	private static Class<?> wrap(Class<?> c) {
		if (!c.isPrimitive()) return c;
		if (c == int.class) return Integer.class;
		if (c == long.class) return Long.class;
		if (c == float.class) return Float.class;
		if (c == double.class) return Double.class;
		if (c == boolean.class) return Boolean.class;
		return c;
	}

	private Compat() {}
}
