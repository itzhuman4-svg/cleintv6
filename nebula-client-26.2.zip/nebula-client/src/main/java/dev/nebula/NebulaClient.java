package dev.nebula;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NebulaClient implements ClientModInitializer {
	public static final Logger LOG = LoggerFactory.getLogger("nebula");

	public static final String TITLE = "Minecraft Nebula Client";
	private static int titleTimer;
	public static KeyMapping menuKey;
	public static KeyMapping zoomKey;
	public static KeyMapping perspKey;
	public static KeyMapping waypointKey;

	@Override
	public void onInitializeClient() {
		Config.load();
		Config.I.ensureDefault();

		KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("nebula", "main"));
		menuKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.nebula.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
		zoomKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.nebula.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));

		perspKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.nebula.perspective", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, cat));

		waypointKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.nebula.waypoint", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, cat));

		HudRenderer.register();
		NickHider.register();
		ShulkerPreview.register();

		AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
			if (player == Minecraft.getInstance().player) Stats.onAttack(entity);
			return InteractionResult.PASS;
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (waypointKey.consumeClick()) if (mc.gui.screen() == null) WorldOverlay.addHere(mc);
			while (menuKey.consumeClick()) mc.gui.setScreen(new NebulaScreen());
			Stats.tick(mc);
			Perf.tick(mc);
			Features.tick(mc);
			Cosmetics.tick(mc);
			if (++titleTimer % 20 == 1) mc.getWindow().setTitle(TITLE);
		});

		ClientLifecycleEvents.CLIENT_STARTED.register(mc -> mc.getWindow().setTitle(TITLE));

		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
			Features.restoreAll(mc);
			Config.save();
		});

		LOG.info("Nebula Client loaded");
	}
}
