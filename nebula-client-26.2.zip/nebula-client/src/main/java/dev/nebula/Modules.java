package dev.nebula;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Every feature: on/off switch + its own configuration page. */
public final class Modules {
	public static final String[] CATS = {"PvP", "Visual & HUD", "Information", "Quality of Life"};

	/** type: T = toggle, S = slider, C = cycle through options */
	public record Setting(String key, String label, char type, double min, double max, double step, double def, String[] opts) {}

	public static final class Mod {
		public final String id, name, cat, desc;
		public final boolean hud, defOn;
		public final List<Setting> settings;

		Mod(String id, String name, String cat, String desc, boolean hud, boolean defOn, List<Setting> s) {
			this.id = id; this.name = name; this.cat = cat; this.desc = desc;
			this.hud = hud; this.defOn = defOn; this.settings = s;
		}

		public boolean on() { return Config.I.flag("mod." + id, defOn); }
		public void setOn(boolean v) { Config.I.flags.put("mod." + id, v); }

		private Setting find(String key) {
			for (Setting s : settings) if (s.key().equals(key)) return s;
			return null;
		}
		public double num(String key) { Setting s = find(key); return Config.I.num(id + "." + key, s == null ? 0 : s.def()); }
		public void setNum(String key, double v) { Config.I.nums.put(id + "." + key, v); }
		public boolean flag(String key) { Setting s = find(key); return Config.I.flag(id + "." + key, s != null && s.def() > 0); }
		public void setFlag(String key, boolean v) { Config.I.flags.put(id + "." + key, v); }
		public int opt(String key) { return (int) Math.round(num(key)); }
	}

	public static final List<Mod> ALL = new ArrayList<>();
	private static final Map<String, Mod> MAP = new HashMap<>();

	public static Mod m(String id) { return MAP.get(id); }
	public static boolean on(String id) { Mod m = MAP.get(id); return m != null && m.on(); }

	private static Setting tog(String k, String l, boolean d) { return new Setting(k, l, 'T', 0, 1, 1, d ? 1 : 0, null); }
	private static Setting sld(String k, String l, double min, double max, double step, double d) { return new Setting(k, l, 'S', min, max, step, d, null); }
	private static Setting cyc(String k, String l, int d, String... o) { return new Setting(k, l, 'C', 0, o.length - 1, 1, d, o); }

	private static void add(String id, String name, String cat, String desc, boolean hud, boolean on, Setting... s) {
		Mod m = new Mod(id, name, cat, desc, hud, on, List.of(s));
		ALL.add(m);
		MAP.put(id, m);
	}

	static {
		String pvp = CATS[0], vis = CATS[1], info = CATS[2], qol = CATS[3];

		add("keystrokes", "Keystrokes", pvp, "Shows WASD, mouse buttons and space as you press them.", true, true,
				cyc("color", "Pressed color", 1, "Cyan", "White", "Green", "Pink", "Orange"),
				tog("mouse", "Show mouse buttons", true), tog("space", "Show space bar", true));
		add("cps", "CPS Counter", pvp, "Clicks per second for left and right mouse.", true, true,
				tog("right", "Show right click CPS", true));
		add("reach", "Reach Display", pvp, "Distance of your last hit on an entity.", true, false,
				sld("decimals", "Decimals", 1, 3, 1, 2));
		add("combo", "Combo Display", pvp, "Counts your hits in a row until you get hit or time out.", true, true,
				sld("timeout", "Reset after (seconds)", 1, 6, 1, 3));
		add("hitbox", "Hitbox Visualization", pvp, "Outlines nearby entities you can see. Red when you can hit them, white when not.", false, false,
				sld("reach", "Your hit reach (blocks)", 2, 6, 0.5, 3), sld("distance", "Draw distance", 8, 48, 4, 24));
		add("hitindicator", "Hit Indicator", pvp, "Flashes a marker at your crosshair when you hit something.", false, false,
				cyc("color", "Color", 0, "White", "Cyan", "Red", "Yellow"),
				sld("size", "Size", 3, 12, 1, 6), sld("duration", "Duration (ticks)", 4, 20, 1, 8));
		add("sprint", "Toggle Sprint", pvp, "Keeps you sprinting at all times while you move, re-sprinting instantly after hits.", false, false,
				cyc("mode", "Sprint when", 0, "Holding forward", "Any movement key"));
		add("totems", "Totem Counter", pvp, "How many Totems of Undying you carry.", true, false);
		add("hurtcam", "No Hurt Cam", pvp, "Stops the screen shaking when you take damage.", false, false);

		add("crosshair", "Custom Crosshair", vis, "Replace the vanilla crosshair, or draw your own pixel by pixel.", false, false,
				cyc("style", "Style", 0, "Cross", "Dot", "Plus", "Circle", "Square", "Custom (drawn)"),
				sld("size", "Size", 2, 14, 1, 4), sld("gap", "Gap", 0, 8, 1, 3), sld("thickness", "Thickness", 1, 4, 1, 1),
				cyc("color", "Color", 0, "White", "Cyan", "Green", "Red", "Pink", "Yellow"),
				tog("outline", "Dark outline", false));
		add("zoom", "Zoom", vis, "Hold C to zoom in with a smooth transition.", false, true,
				sld("fov", "Zoom FOV", 5, 60, 1, 15), tog("smooth", "Smooth zoom", true),
				sld("speed", "Smoothness speed", 3, 20, 1, 10));
		add("perspective", "Freelook", vis, "Hold Left Alt and move the mouse to look around your character without turning it.", false, false,
				cyc("view", "View", 0, "Behind you", "In front of you"));
		add("armor", "Armor Status", vis, "Armor and held-item durability in framed slots.", true, true,
				cyc("layout", "Layout", 0, "Horizontal", "Vertical"), cyc("mode", "Number shows", 0, "Durability", "Percent"),
				tog("held", "Include held item", false));
		add("effects", "Potion Effects", vis, "Active effects with their remaining time.", true, true,
				cyc("layout", "Layout", 0, "Vertical", "Horizontal"), tog("timer", "Show timer", true));
		add("nickname", "Nickname Badge", vis, "Your name with the Nebula logo beside it.", true, false,
				tog("name", "Show my nickname", true), tog("logo", "Show logo", true));
		add("waypoints", "Waypoints", vis, "Saved locations with a beam you can see from far away.", true, true,
				tog("beam", "Show beam", true), sld("width", "Beam width", 1, 6, 1, 3), tog("names", "Show names and distance", true),
				tog("list", "Show list on HUD", false), sld("max", "Max shown", 1, 10, 1, 5));

		add("saturation", "Saturation", info, "Hunger and saturation, with a gold saturation bar on your hunger icons (like AppleSkin).", true, false,
				tog("overlay", "Gold bar on hunger icons", true), tog("text", "Show numbers on HUD", true));
		add("biome", "Biome", info, "The biome you are standing in.", true, false);
		add("cpu", "CPU Usage", info, "How much CPU the game is using.", true, false);
		add("memory", "Memory", info, "How much RAM the game is using.", true, false,
				cyc("unit", "Show as", 0, "MB used / max", "Percent"));
		add("fps", "FPS", info, "Frames per second.", true, true);
		add("ping", "Ping", info, "Latency to the server.", true, true);
		add("coords", "Coordinates", info, "Your current X, Y and Z.", true, true,
				tog("decimals", "Show decimals", false));
		add("facing", "Facing", info, "The direction you are looking.", true, true);
		add("tps", "TPS", info, "Estimated server ticks per second.", true, false);
		add("speed", "Speed Meter", info, "How fast you are moving.", true, false,
				cyc("unit", "Unit", 0, "Blocks/s", "km/h"));
		add("playtime", "Playtime", info, "Session time and total time played.", true, false,
				tog("total", "Show total playtime", true));
		add("deathinfo", "Death Info", info, "Where you last died and how many times.", true, false);
		add("clock", "Clock", info, "Your real-world time.", true, false,
				cyc("format", "Format", 0, "12 hour", "24 hour"), tog("seconds", "Show seconds", false));

		add("fullbright", "Fullbright", qol, "See clearly in the dark.", false, false,
				sld("level", "Brightness", 2, 15, 1, 15));
		add("fov", "FOV Changer", qol, "Set any field of view, even past the vanilla limit.", false, false,
				sld("fov", "FOV", 30, 130, 1, 90));
		add("time", "Time Changer", qol, "Change the time of day for you only. The server is not affected.", false, false,
				cyc("preset", "Time", 1, "Day", "Noon", "Sunset", "Night", "Midnight", "Sunrise", "Custom"),
				sld("custom", "Custom time (ticks)", 0, 24000, 500, 6000));
		add("weather", "Weather Changer", qol, "Change the weather for you only. The server is not affected.", false, false,
				cyc("weather", "Weather", 0, "Clear", "Rain", "Thunder"));
		add("inventory", "Inventory HUD", qol, "Your inventory always on screen.", true, false);
		add("itemcounter", "Item Counter", qol, "How many of your held item you carry.", true, false);
		add("fpsboost", "FPS Boost", qol, "Lowers costly video settings while on, and puts them back when you turn it off.", false, false,
				cyc("particles", "Particles", 1, "Keep", "Decreased", "Minimal"),
				tog("clouds", "Turn clouds off", true), tog("shadows", "Turn entity shadows off", true),
				tog("blend", "Lower biome blend", true), tog("framerate", "Uncap framerate limit", true),
				tog("vsync", "Turn VSync off", true), sld("renderdist", "Render distance cap (0 = unchanged)", 0, 32, 2, 0));
		add("shulkerpreview", "Shulker Preview", qol, "Hover a shulker box to see what is inside it.", false, false,
				sld("max", "Max lines shown", 4, 27, 1, 12));
		add("nickhider", "Nick Hider", qol, "Replaces your username in game messages (join, death, system lines).", false, false,
				cyc("alias", "Show as", 0, "Player", "Hidden", "Nebula", "Orbitive", "Anonymous", "Steve"));
	}

	private Modules() {}
}
