package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Gray / black / cyan / blue theme. */
final class Ui {
	static final int BG = 0xF5070A0F, TOP = 0xFF2B2E33, PANEL = 0xFF23262B, PANEL2 = 0xFF2D3036, HOVER = 0xFF3A3E45, EDGE = 0xFF42474F;
	static final int CYAN = 0xFF00D4FF, BLUE = 0xFF5C9BFF, ACTIVE = 0xFF245FC4;
	static final int[] SWATCH = {0x00E5FF, 0xFF5CA8, 0x7CFF6B, 0xFFC93C, 0xA78BFF, 0xFF6B4A, 0xFFFFFF, 0xFF3B3B, 0x3B7BFF, 0xC6FF3B, 0xFF3BE0, 0x2BD9B0};
	static final int TEXT = 0xFFE6EDF7, DIM = 0xFF8A94A6, MUTED = 0xFF566073;

	static void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) { g.fill(x, y, x + w, y + h, c); }

	static void border(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) {
		rect(g, x, y, w, 1, c);
		rect(g, x, y + h - 1, w, 1, c);
		rect(g, x, y, 1, h, c);
		rect(g, x + w - 1, y, 1, h, c);
	}

	static void gradH(GuiGraphicsExtractor g, int x, int y, int w, int h, int c1, int c2) {
		for (int i = 0; i < w; i++) rect(g, x + i, y, 1, h, lerp(c1, c2, i / (float) Math.max(1, w - 1)));
	}

	static int width(String s) { return Minecraft.getInstance().font.width(s); }

	static void text(GuiGraphicsExtractor g, String s, int x, int y, int c) { g.text(Minecraft.getInstance().font, s, x, y, c); }

	static void center(GuiGraphicsExtractor g, String s, int cx, int y, int c) { text(g, s, cx - width(s) / 2, y, c); }

	static int spacedWidth(String s) {
		int w = 0;
		for (int i = 0; i < s.length(); i++) w += width(String.valueOf(s.charAt(i))) + 1;
		return Math.max(0, w - 1);
	}

	static void spaced(GuiGraphicsExtractor g, String s, int x, int y, int c) {
		int cx = x;
		for (int i = 0; i < s.length(); i++) {
			String t = String.valueOf(s.charAt(i));
			text(g, t, cx, y, c);
			cx += width(t) + 1;
		}
	}

	static void spacedCenter(GuiGraphicsExtractor g, String s, int cx, int y, int c) { spaced(g, s, cx - spacedWidth(s) / 2, y, c); }

	static void pencil(GuiGraphicsExtractor g, int x, int y, int c) {
		for (int i = 0; i < 5; i++) { g.fill(x + 5 - i, y + i, x + 7 - i, y + i + 1, c); }
		g.fill(x, y + 5, x + 2, y + 7, c);
	}

	static boolean hit(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

	/** Blends two ARGB colours, alpha included. */
	static int lerpArgb(int a, int b, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
		int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
		int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
		int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
		return (aa << 24) | (r << 16) | (g << 8) | bl;
	}

	static int lerp(int a, int b, float t) {
		int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
		int gr = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
		int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
		return 0xFF000000 | (r << 16) | (gr << 8) | bl;
	}

	/** Word-wrapped text; stops after maxLines (adds ".." if cut). Returns lines used. */
	static int wrap(GuiGraphicsExtractor g, String s, int x, int y, int maxW, int c, int maxLines) {
		StringBuilder line = new StringBuilder();
		int lines = 0;
		String[] words = s.split(" ");
		for (int i = 0; i < words.length; i++) {
			String test = line.length() == 0 ? words[i] : line + " " + words[i];
			if (width(test) > maxW && line.length() > 0) {
				if (lines == maxLines - 1) { text(g, fit(line + "..", maxW), x, y + lines * 10, c); return lines + 1; }
				text(g, line.toString(), x, y + lines * 10, c);
				lines++;
				line = new StringBuilder(words[i]);
			} else {
				line = new StringBuilder(test);
			}
		}
		if (line.length() > 0) { text(g, fit(line.toString(), maxW), x, y + lines * 10, c); lines++; }
		return lines;
	}

	static String fit(String s, int maxW) {
		if (width(s) <= maxW) return s;
		while (s.length() > 1 && width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
		return s + "..";
	}

	private Ui() {}
}
