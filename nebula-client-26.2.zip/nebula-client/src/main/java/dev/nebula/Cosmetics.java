package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.Identifier;

import java.util.List;
import java.util.Set;

/**
 * Capes are real textures swapped onto your own skin (see AbstractClientPlayerMixin).
 * Wings, auras and fists are particles drawn on your own client; other players cannot see them
 * unless you add a server/backend that syncs cosmetics.
 */
public final class Cosmetics {
	public record Item(String id, String name, String desc, int c1, int c2, boolean anim) {}

	public static final String[] CATS = {"Capes", "Wings", "Auras", "Fists"};

	private static final Item NONE = new Item("none", "None", "Nothing equipped", 0x333344, 0x22222E, false);

	private static final List<Item> CAPES = List.of(NONE,
			new Item("cherry", "Cherry Blossom", "Pink cape with blossoms and a darker petal hem, inspired by Mojang's cherry cape (own pixel art)", 0xF9C6DA, 0xE58AB4, false),
			new Item("nebula", "Nebula Drift", "Purple starfield with a glowing ribbon", 0x6A35C9, 0x1A1A55, false),
			new Item("ember", "Ember Obsidian", "Black cape with a lava crack running down it", 0x1B1B1F, 0xFF6A1A, false),
			new Item("ocean", "Deep Ocean", "Teal gradient with foam-line waves", 0x2EC4B6, 0x0B3C5D, false),
			new Item("aurora", "Aurora", "Northern-lights bands, green to violet", 0x39FFB6, 0x7B2FF7, false),
			new Item("sunset", "Sunset Horizon", "Orange sky fading into purple with a low sun", 0xFF9A5A, 0x4A2A8A, false),
			new Item("frostbite", "Frostbite", "Icy white-blue with crystal patterns", 0xE6F6FF, 0x6FB6F0, false),
			new Item("emerald", "Emerald Forest", "Deep green with leaf stripes", 0x3CCB7A, 0x0B4D2E, false),
			new Item("royal", "Royal Gold", "Midnight cape with a gold trim and crown", 0x23233A, 0xFFD040, false));

	private static final List<Item> WINGS = List.of(NONE,
			new Item("angel", "Angel Wings", "White light wings that gently flap", 0xFFFFFF, 0xBFD9FF, true),
			new Item("crystal", "Crystal Wings", "Still, glassy wings of light", 0xCFF5FF, 0x7FBFFF, false),
			new Item("phoenix", "Phoenix Wings", "Flaming wings that flap", 0xFFB020, 0xE02A00, true),
			new Item("shadow", "Shadow Wings", "Still wings of blue soul fire", 0x2DE6F0, 0x1B2A6B, false),
			new Item("blossom", "Blossom Wings", "Wings of drifting cherry petals", 0xF7B6D2, 0xD9689A, false),
			new Item("frost", "Frost Wings", "Snowflake wings that flap slowly", 0xE8F8FF, 0x8CC8FF, true),
			new Item("storm", "Storm Wings", "Crackling electric wings that flap", 0xFFFF9A, 0x6A5CFF, true),
			new Item("emerald", "Emerald Wings", "Still green sparkle wings", 0x7CFF9A, 0x1E8F4A, false));

	private static final List<Item> AURAS = List.of(NONE,
			new Item("arcane", "Arcane Aura", "Enchanting-table glyphs spiral into you", 0xB58CFF, 0x4B2A9E, true),
			new Item("halo", "Halo", "A glowing ring above your head", 0xFFF3B0, 0xFFD54A, true),
			new Item("sakura", "Sakura Breeze", "Cherry petals drift around you", 0xF7B6D2, 0xD9689A, true),
			new Item("frost", "Frost Veil", "Soft snowflakes hover around you", 0xE8F8FF, 0x8CC8FF, false),
			new Item("love", "Heartglow", "Occasional floating hearts", 0xFF7A9C, 0xC2185B, false),
			new Item("emberring", "Ember Ring", "A ring of flames circling your waist", 0xFFB020, 0xE02A00, true),
			new Item("soulorbit", "Soul Orbit", "Three blue flames orbit you", 0x2DE6F0, 0x1B2A6B, true),
			new Item("sparks", "Storm Sparks", "Electric sparks crackle around you", 0xFFFF9A, 0x6A5CFF, false),
			new Item("stardust", "Stardust", "Glowing motes float around you", 0xFFFFFF, 0x9FD8FF, false));

	private static final List<Item> FISTS = List.of(NONE,
			new Item("ember", "Ember Fists", "Flames burst from your fist when you attack", 0xFFB020, 0xE02A00, true),
			new Item("frost", "Frost Fists", "Snowflakes on every swing", 0xE8F8FF, 0x8CC8FF, true),
			new Item("shock", "Shock Fists", "Electric sparks on attack", 0xFFFF9A, 0x6A5CFF, true),
			new Item("blossom", "Blossom Fists", "Petals scatter as you hit", 0xF7B6D2, 0xD9689A, true),
			new Item("soul", "Soul Fists", "Blue soul fire on attack", 0x2DE6F0, 0x1B2A6B, true),
			new Item("emerald", "Emerald Fists", "Green sparkles on attack", 0x7CFF9A, 0x1E8F4A, true),
			new Item("star", "Star Fists", "Bright star flashes on attack", 0xFFFFFF, 0x9FD8FF, true),
			new Item("love", "Love Fists", "Hearts pop out when you hit", 0xFF7A9C, 0xC2185B, true));

	public static List<Item> items(int cat) {
		return switch (cat) { case 0 -> CAPES; case 1 -> WINGS; case 2 -> AURAS; default -> FISTS; };
	}

	public static String get(int cat) {
		return switch (cat) { case 0 -> Config.I.cape; case 1 -> Config.I.wings; case 2 -> Config.I.aura; default -> Config.I.fists; };
	}

	public static void set(int cat, String id) {
		switch (cat) { case 0 -> Config.I.cape = id; case 1 -> Config.I.wings = id; case 2 -> Config.I.aura = id; default -> Config.I.fists = id; }
		Config.save();
	}

	/** Texture id for the equipped cape, or null. Read by the mixin. */
	public static Identifier capeTexture() {
		String c = Config.I.cape;
		if (c == null || c.equals("none")) return null;
		return Identifier.fromNamespaceAndPath("nebula", "capes/" + c);
	}

	// ------------------------------------------------------------ particle cosmetics

	private static int t;
	private static final Set<String> FLAPPING = Set.of("angel", "phoenix", "frost", "storm");

	private static void spawn(ClientLevel l, ParticleOptions p, double x, double y, double z, double vx, double vy, double vz) {
		l.addParticle(p, x, y, z, vx, vy, vz);
	}

	static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		ClientLevel lvl = mc.level;
		if (p == null || lvl == null || Config.I.perfProfile == 0) return;
		t++;

		double x = p.getX(), y = p.getY(), z = p.getZ();
		double yaw = Math.toRadians(p.yBodyRot);
		double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // forward
		double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // player's right

		wings(lvl, Config.I.wings, x, y, z, fx, fz, rx, rz);
		aura(lvl, p, Config.I.aura, x, y, z);
		fists(mc, lvl, Config.I.fists, x, y, z, fx, fz, rx, rz);
	}

	private static void wings(ClientLevel l, String id, double x, double y, double z, double fx, double fz, double rx, double rz) {
		ParticleOptions part = switch (id) {
			case "angel", "crystal" -> ParticleTypes.END_ROD;
			case "phoenix" -> ParticleTypes.FLAME;
			case "shadow" -> ParticleTypes.SOUL_FIRE_FLAME;
			case "blossom" -> ParticleTypes.CHERRY_LEAVES;
			case "frost" -> ParticleTypes.SNOWFLAKE;
			case "storm" -> ParticleTypes.ELECTRIC_SPARK;
			case "emerald" -> ParticleTypes.HAPPY_VILLAGER;
			default -> null;
		};
		if (part == null) return;
		if (t % (id.equals("phoenix") ? 2 : 3) != 0) return;
		double flap = FLAPPING.contains(id) ? Math.sin(t * 0.1) * 0.25 : 0;
		for (int side = -1; side <= 1; side += 2) {
			for (int i = 0; i < 6; i++) {
				double out = 0.2 + i * 0.2;
				double back = 0.28 + i * 0.04;
				double h = 1.25 + 0.3 * Math.sin(i * 0.65) + flap * out;
				spawn(l, part, x - fx * back + rx * side * out, y + h, z - fz * back + rz * side * out, 0, 0, 0);
			}
		}
	}

	private static void aura(ClientLevel l, LocalPlayer p, String id, double x, double y, double z) {
		switch (id) {
			case "arcane" -> {
				for (int i = 0; i < 2; i++) {
					double a = Math.random() * Math.PI * 2;
					double px = x + Math.cos(a) * 0.9, py = y + 0.2 + Math.random() * 1.8, pz = z + Math.sin(a) * 0.9;
					spawn(l, ParticleTypes.ENCHANT, px, py, pz, x - px, 0.2, z - pz);
				}
			}
			case "halo" -> {
				if (t % 2 != 0) return;
				double hy = y + p.getBbHeight() + 0.3;
				for (int i = 0; i < 5; i++) {
					double a = t * 0.12 + i * (Math.PI * 2 / 5);
					spawn(l, ParticleTypes.END_ROD, x + Math.cos(a) * 0.32, hy, z + Math.sin(a) * 0.32, 0, 0, 0);
				}
			}
			case "sakura" -> {
				if (t % 2 == 0)
					spawn(l, ParticleTypes.CHERRY_LEAVES, x + (Math.random() - 0.5) * 2.4, y + 2.4, z + (Math.random() - 0.5) * 2.4, 0, 0, 0);
			}
			case "frost" -> {
				if (t % 3 == 0) {
					double a = Math.random() * Math.PI * 2;
					spawn(l, ParticleTypes.SNOWFLAKE, x + Math.cos(a) * 0.9, y + 0.3 + Math.random() * 1.7, z + Math.sin(a) * 0.9, 0, 0, 0);
				}
			}
			case "love" -> {
				if (t % 14 == 0)
					spawn(l, ParticleTypes.HEART, x + (Math.random() - 0.5) * 0.8, y + 1.9, z + (Math.random() - 0.5) * 0.8, 0, 0.02, 0);
			}
			case "emberring" -> {
				for (int i = 0; i < 4; i++) {
					double a = t * 0.15 + i * (Math.PI / 2);
					spawn(l, ParticleTypes.FLAME, x + Math.cos(a) * 0.7, y + 0.9, z + Math.sin(a) * 0.7, 0, 0.005, 0);
				}
			}
			case "soulorbit" -> {
				for (int i = 0; i < 3; i++) {
					double a = t * 0.1 + i * (Math.PI * 2 / 3);
					spawn(l, ParticleTypes.SOUL_FIRE_FLAME, x + Math.cos(a) * 0.9, y + 0.6 + i * 0.5, z + Math.sin(a) * 0.9, 0, 0, 0);
				}
			}
			case "sparks" -> {
				if (t % 3 == 0) {
					double a = Math.random() * Math.PI * 2;
					spawn(l, ParticleTypes.ELECTRIC_SPARK, x + Math.cos(a) * 0.7, y + 0.2 + Math.random() * 1.8, z + Math.sin(a) * 0.7, 0, 0, 0);
				}
			}
			case "stardust" -> {
				if (t % 3 == 0) {
					double a = Math.random() * Math.PI * 2;
					spawn(l, ParticleTypes.GLOW, x + Math.cos(a) * 0.8, y + 0.2 + Math.random() * 1.8, z + Math.sin(a) * 0.8, 0, 0.01, 0);
				}
			}
			default -> { }
		}
	}

	private static void fists(Minecraft mc, ClientLevel l, String id, double x, double y, double z, double fx, double fz, double rx, double rz) {
		if (id.equals("none") || mc.gui.screen() != null || !mc.options.keyAttack.isDown()) return;
		ParticleOptions part = switch (id) {
			case "ember" -> ParticleTypes.FLAME;
			case "frost" -> ParticleTypes.SNOWFLAKE;
			case "shock" -> ParticleTypes.ELECTRIC_SPARK;
			case "blossom" -> ParticleTypes.CHERRY_LEAVES;
			case "soul" -> ParticleTypes.SOUL_FIRE_FLAME;
			case "emerald" -> ParticleTypes.HAPPY_VILLAGER;
			case "star" -> ParticleTypes.END_ROD;
			case "love" -> ParticleTypes.HEART;
			default -> null;
		};
		if (part == null) return;
		double hx = x + rx * 0.4 + fx * 0.45, hy = y + 1.1, hz = z + rz * 0.4 + fz * 0.45;
		for (int i = 0; i < 2; i++)
			spawn(l, part, hx + (Math.random() - 0.5) * 0.15, hy + (Math.random() - 0.5) * 0.15, hz + (Math.random() - 0.5) * 0.15,
					(Math.random() - 0.5) * 0.04, 0.02, (Math.random() - 0.5) * 0.04);
	}

	private Cosmetics() {}
}
