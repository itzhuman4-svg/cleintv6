package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;

import java.util.List;

/** Drag HUD elements anywhere. Click one to select it, then resize it / toggle its background. */
final class HudEditScreen extends UiScreen {
	private String selected, dragging;
	private float offX, offY;

	HudEditScreen() { super("Edit HUD"); }

	@Override protected boolean blur() { return false; }
	@Override protected int dim() { return 0x55050810; }

	@Override
	void draw(GuiGraphicsExtractor g, Minecraft mc) {
		List<HudRenderer.Item> items = HudRenderer.layout(mc, true);
		HudRenderer.drawItems(g, mc, items);

		for (HudRenderer.Item it : items) {
			boolean sel = it.id().equals(selected);
			Ui.border(g, (int) it.x() - 3, (int) it.y() - 3, (int) it.w() + 6, (int) it.h() + 6, sel ? Ui.CYAN : 0x66FFFFFF);
		}

		int tw = 360, th = 48;
		int tx = (width - tw) / 2, ty = 10;
		boolean overBar = Ui.hit(mx, my, tx, ty, tw, th);
		Ui.rect(g, tx, ty, tw, th, Ui.PANEL);
		Ui.border(g, tx, ty, tw, th, Ui.EDGE);
		Ui.gradH(g, tx, ty, tw, 2, Ui.CYAN, Ui.BLUE);

		if (click && !overBar) {
			selected = null;
			for (int i = items.size() - 1; i >= 0; i--) {
				HudRenderer.Item it = items.get(i);
				if (Ui.hit(mx, my, (int) it.x() - 3, (int) it.y() - 3, (int) it.w() + 6, (int) it.h() + 6)) {
					selected = it.id();
					dragging = it.id();
					offX = mx - it.x();
					offY = my - it.y();
					break;
				}
			}
		}
		if (dragging != null) {
			if (!down) {
				dragging = null;
			} else {
				for (HudRenderer.Item it : items) {
					if (!it.id().equals(dragging)) continue;
					float nx = Mth.clamp(mx - offX, 0, Math.max(0, width - it.w()));
					float ny = Mth.clamp(my - offY, 0, Math.max(0, height - it.h()));
					Config.P p = Config.I.p(dragging);
					p.x = nx / (double) width;
					p.y = ny / (double) height;
				}
			}
		}

		int by = ty + 26, bx = tx + 8;
		if (selected == null) {
			Ui.text(g, "Click an element to select it, drag to move.", tx + 8, ty + 9, Ui.DIM);
		} else {
			Config.P p = Config.I.p(selected);
			Ui.text(g, "Selected: " + Modules.m(selected).name, tx + 8, ty + 9, Ui.TEXT);
			if (button(g, "-", bx, by, 18, 16, false)) p.scale = Math.max(0.5f, Math.round((p.scale - 0.1f) * 10) / 10f);
			Ui.center(g, String.format("%.1fx", p.scale), bx + 18 + 20, by + 4, Ui.TEXT);
			if (button(g, "+", bx + 58, by, 18, 16, false)) p.scale = Math.min(3f, Math.round((p.scale + 0.1f) * 10) / 10f);
			if (button(g, "BG: " + (p.bg ? "ON" : "OFF"), bx + 82, by, 58, 16, p.bg)) p.bg = !p.bg;
			if (button(g, "Reset", bx + 144, by, 46, 16, false)) { p.x = null; p.y = null; p.scale = 1f; }
		}
		if (button(g, "All BG: " + (Config.I.allBg ? "ON" : "OFF"), tx + 200, by, 76, 16, Config.I.allBg)) Config.I.allBg = !Config.I.allBg;
		if (button(g, "Done", tx + 282, by, 70, 16, false)) { Config.save(); mc.gui.setScreen(new NebulaScreen()); }
	}
}
